<?php

/**
 * Module's helper
 *
 * @category   MageCore
 * @package    Oro_Design
 * @copyright  Copyright (c) 2014 Oro Inc. DBA MageCore (http://www.magecore.com)
 */
class Oro_Design_Helper_Data extends Mage_Core_Helper_Abstract
{

}
