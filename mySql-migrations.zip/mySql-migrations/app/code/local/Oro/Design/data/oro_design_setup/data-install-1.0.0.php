<?php
/**
 * @category   Oro
 * @package    Oro_Design
 * @copyright  Copyright (c) 2014 Oro Inc. DBA MageCore (http://www.magecore.com)
 */
$installer = $this;
$installer->setConfigData('design/header/logo_src', 'images/logo.png');
$installer->setConfigData('general/store_information/phone', '888-111-1111');
$installer->setConfigData('design/footer/copyright', 'Copyright &copy; 2015, magecore.com All rights reserved.');